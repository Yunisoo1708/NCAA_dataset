Library v2: 10,000,000 unique sequences, lengths 6-30 (every integer), one xz-compressed TSV per length (lib_L06.tsv.xz ... lib_L30.tsv.xz; open with 7-Zip or xz).
Pool: 32 verified RCSB CCD monomers (real CCD codes only; no custom CCDs).
Mix: 4,000,000 single-class (n_classes = 1; includes 32 homo-oligomers per length) and 6,000,000 multi-class (n_classes >= 2).
Per length: 240,000 multi-class; ~165,000 single-class (L=6 has 39,776 because that is all the single-class space allows at half capacity; the shortfall was spread over L=7-30).
Columns: combo_id, length, mix_type, n_classes, ccd_sequence, class_pattern, af3_protein_entry, boltz2_protein_entry, rf3_seq
Assumptions to test on a few jobs first:
  * The sequence letter under every modified position is "A".
  * Boltz-2 modifications are documented as CCD-only; BAL, XCP, STA are typed Peptide-like on RCSB.
  * assemble_inputs.py wraps entries into full input files with empty MSAs.
